const multer = require('multer')
var storage = multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, "./public/files");
    },
    filename: function (req, file, cb) {
      cb(null, Date.now() + 'NOTEASAP' + file.originalname);
    },
  });
const maxSize = 10 * 1024 * 1024; // for 1MB

var upload = multer({
  storage: storage,
  fileFilter: (req, file, cb) => {
    console.log(file )
    if ( file.mimetype == "application/vnd.openxmlformats-officedocument.wordprocessingml.document" ||file.mimetype == "application/vnd.openxmlformats-officedocument.presentationml.presentation" || file.mimetype == "application/zip" ||file.mimetype=="file/pptx") {
      cb(null, true);
    } else {
      cb({success: false,
        msg: 'Invalid file type. Only jpg, png image files are allowed.'},false);
    }
  },
  limits: { fileSize: maxSize },
}).single('file');
module.exports = upload