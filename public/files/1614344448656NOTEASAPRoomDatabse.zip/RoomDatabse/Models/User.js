const mongoose = require('mongoose');
const User = mongoose.model('User', {
    fname: {
        type: String,
        requried: true
    },
    lname: {
        type: String,
        requried: true
    },
    uname: {
        type: String,
        required: true,
        unique: true
    },
    password: {
        type: String,
        required: true
    },
    tokens: [{
        token: {
            type: String
        }
    }]

})
module.exports = User;