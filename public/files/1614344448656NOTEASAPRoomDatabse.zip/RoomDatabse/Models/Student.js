const mongoose = require('mongoose');
const Student = mongoose.model('Student', {
    name: {
        type: String,
        requried: true
    },
    age: {
        type: String,
        requried: true
    },
    gender: {
        type: String,
        required: true
    },
    address: {
        type: String,
        required: true
    }

})
module.exports = Student;