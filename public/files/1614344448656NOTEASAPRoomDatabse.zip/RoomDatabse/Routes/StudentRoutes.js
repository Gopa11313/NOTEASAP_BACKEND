const express=require('express');
const jwt=require('jsonwebtoken')
const router=express.Router();
const bcrypt=require('bcryptjs')
const auth=require('../middleware/auth')
const Student=require('../Models/Student');
const { response } = require('express');
const saltRounds = 10;
const {check,validationResult}=require('express-validator')


router.post("/student/add",auth.varifyUser,(req,res)=>{
            var data1 = req.body;
            var name = data1.name
            var age = data1.age
            var gender = data1.gender
            var address = data1.address
            var student= new Student({name:name, age:age, gender:gender, address:address})
            student.save().then(function(){
                console.log(student)
                res.status(201).json({success:true,message:"Done"})
            }).catch(function(e){
                res.status(500).json({success:false,Message: "helllo"})
            })
})


router.get("/get/student",auth.varifyUser,(req,res)=>{
        Student.find().then(function (data) {
            res.status(200).json({success:true,list:data})
        }).catch(function(e){
            res.send(500).json({success:false})
        })
})
router.delete("/delete/student/:id",auth.varifyUser,(req,res)=>{
    const id=req.params.id
    Student.deleteOne({_id:id}).then(function(){
        res.status(200).json({success:true,msg:"Succesfully Delete"})
    }).catch(function(e){
        res.status(500).json({success:false})
    })
})

router.put('/update/student/:id',(req,res)=>{
    const id=req.params.id
    const name=req.body.name
    const age=req.body.age
    const gender=req.body.gender
    const address=req.body.address
    Student.updateOne({_id:id},{name:name},{age:age},{gender:gender},{address:address}).then(function(){
        res.status(200).json({success:true,msg:"Succesfully Updated"})
    }).catch(function(e){
        res.status(500).json({success:false})
    })
})

module.exports=router