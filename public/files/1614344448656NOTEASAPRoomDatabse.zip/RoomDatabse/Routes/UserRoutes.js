const express = require('express');
const jwt = require('jsonwebtoken')
const router = express.Router();
const bcrypt = require('bcryptjs')
const User = require('../Models/User');
const { response } = require('express');
const saltRounds = 10;
const { check, validationResult } = require('express-validator')


router.post("/user/add",
    [
        check('lname', "Name must be filled").not().isEmpty(),
        check('fname', "Name must be filled").not().isEmpty(),
        check('uname', "Enter a valid email").isEmail(),
        check('password', "Password must be 6 latter long").isLength({ min: 4 })
    ],
    (req, res) => {
        const errros = validationResult(req);
        if (errros.isEmpty()) {
            var data1 = req.body;
            var fname = data1.fname;
            var lname = data1.lname
            var uname = data1.uname;
            var password = data1.password
            const hash = bcrypt.hashSync(password, saltRounds);
            var data = new User({ fname: fname, lname: lname, uname: uname, password: hash })
            data.save().then(function () {
                res.status(201).json({
                    success: true
                })
            }).catch(function (e) {
                res.send(e)
                res.status(500).json({ Message: e })
            })
        }
        else {
            res.status(400).json(errros.array())
            res.send(errros.array())
        }
    })

router.post('/user/login', (req, res) => {
    const body = req.body;
    User.findOne({ uname: body.uname }).then(function (userData) {
        if (userData == null) {
            return res.status(201).json({ success: false, Message: "Invalid User!!" })
        }
        bcrypt.compare(body.password, userData.password, function (err, result) {
            if (result == false) {
                return res.status(201).json({ success: false, Message: "Invalid User!!" })
            }
            const token = jwt.sign({ userId: userData._id }, 'secretkey');
            res.status(200).json({ success: true, token: token })
        })

    }).catch(function (e) {
            return res.status(400).json({success:false})
    })
})
module.exports = router