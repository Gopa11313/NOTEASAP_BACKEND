const express=require('express');
const bodyparser=require('body-parser');
const User_Router=require("./Routes/UserRoutes")
const Student_router=require("./Routes/StudentRoutes")
const mongooes=require("./Db/db")
const app=express();
app.use(bodyparser.urlencoded({extended:false}))
app.use(express.json())

app.use(User_Router)
app.use(Student_router)


app.listen(3000)